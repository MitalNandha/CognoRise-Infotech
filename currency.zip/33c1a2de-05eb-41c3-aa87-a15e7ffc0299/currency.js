// script.js
const fromCurrency = document.getElementById("from-currency");
const toCurrency = document.getElementById("to-currency");
const amount = document.getElementById("amount");
const result = document.getElementById("result");
const convertBtn = document.getElementById("convert-btn");

// Fetch exchange rates and populate the currency dropdowns
async function populateCurrencies() {
    try {
        const response = await fetch("https://api.exchangerate-api.com/v4/latest/USD");
        const data = await response.json();

        const currencies = Object.keys(data.rates);

        currencies.forEach(currency => {
            const option1 = document.createElement("option");
            const option2 = document.createElement("option");
            option1.value = currency;
            option2.value = currency;
            option1.textContent = currency;
            option2.textContent = currency;

            fromCurrency.appendChild(option1);
            toCurrency.appendChild(option2);
        });
    } catch (error) {
        console.error("Error fetching exchange rates:", error);
        result.textContent = "Failed to fetch currency data.";
    }
}

// Perform currency conversion
async function convertCurrency() {
    const from = fromCurrency.value;
    const to = toCurrency.value;
    const amountValue = parseFloat(amount.value);

    if (!from || !to || isNaN(amountValue) || amountValue <= 0) {
        result.textContent = "Please provide valid inputs.";
        return;
    }

    try {
        const response = await fetch(`https://api.exchangerate-api.com/v4/latest/${from}`);
        const data = await response.json();

        const rate = data.rates[to];
        const convertedAmount = (amountValue * rate).toFixed(2);

        result.textContent = `${amountValue} ${from} = ${convertedAmount} ${to}`;
    } catch (error) {
        console.error("Error converting currency:", error);
        result.textContent = "Conversion failed. Try again.";
    }
}

// Initialize app
populateCurrencies();
convertBtn.addEventListener("click", convertCurrency);
