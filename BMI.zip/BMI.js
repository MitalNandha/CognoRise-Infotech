// script.js
const weightInput = document.getElementById("weight");
const heightInput = document.getElementById("height");
const calculateBtn = document.getElementById("calculate-btn");
const result = document.getElementById("result");

calculateBtn.addEventListener("click", () => {
    const weight = parseFloat(weightInput.value);
    const heightCm = parseFloat(heightInput.value);

    if (isNaN(weight) || isNaN(heightCm) || weight <= 0 || heightCm <= 0) {
        result.textContent = "Please enter valid positive values for weight and height.";
        return;
    }

    // Convert height to meters and calculate BMI
    const heightM = heightCm / 100;
    const bmi = (weight / (heightM * heightM)).toFixed(2);

    // Determine BMI category
    let category;
    if (bmi < 18.5) {
        category = "Underweight";
    } else if (bmi >= 18.5 && bmi < 24.9) {
        category = "Normal weight";
    } else if (bmi >= 25 && bmi < 29.9) {
        category = "Overweight";
    } else {
        category = "Obesity";
    }

    result.textContent = `Your BMI is ${bmi}. Category: ${category}`;
});
