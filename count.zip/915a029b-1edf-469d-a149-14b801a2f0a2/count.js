// script.js
const targetDateInput = document.getElementById("target-date");
const startTimerBtn = document.getElementById("start-timer-btn");
const timeRemainingDisplay = document.getElementById("time-remaining");

let countdownInterval;

startTimerBtn.addEventListener("click", () => {
    const targetDateValue = targetDateInput.value;

    if (!targetDateValue) {
        alert("Please select a valid target date and time.");
        return;
    }

    const targetDate = new Date(targetDateValue);

    if (targetDate <= new Date()) {
        alert("Please select a future date and time.");
        return;
    }

    // Clear any existing interval
    clearInterval(countdownInterval);

    // Start the countdown
    countdownInterval = setInterval(() => {
        const now = new Date();
        const timeDiff = targetDate - now;

        if (timeDiff <= 0) {
            clearInterval(countdownInterval);
            timeRemainingDisplay.textContent = "00:00:00:00";
            alert("Countdown reached!");
            return;
        }

        const days = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((timeDiff % (1000 * 60)) / 1000);

        timeRemainingDisplay.textContent = `${days.toString().padStart(2, "0")}:${hours
            .toString()
            .padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${seconds
            .toString()
            .padStart(2, "0")}`;
    }, 1000);
});
